package mapeador;

import dto.CompraDTO;
import modelo.Compra;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y utilizada en otros lugares.

public class CompraMapeador {

    public CompraDTO toDTO(Compra compra) {
        // Convierte una entidad Compra a un DTO CompraDTO.

        if (compra == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        CompraDTO dto = new CompraDTO();
        // Crea una nueva instancia del DTO.

        dto.setClienteId(compra.getCliente() != null ? compra.getCliente().getId() : null);
        // Asigna el id del cliente si existe; si no, asigna null.

        dto.setTotal(compra.getTotal());
        // Copia el total de la compra.

        // Convierte el enum MetodoPago a su representación en String para el DTO.
        dto.setMetodoPago(compra.getMetodoPago() != null ? compra.getMetodoPago().name() : null);

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public Compra toEntidad(CompraDTO dto) {
        // Convierte un DTO CompraDTO a una entidad Compra.

        if (dto == null) return null;
        // Retorna null si el DTO es null para evitar errores.

        Compra compra = new Compra();
        // Crea una nueva instancia de la entidad.

        compra.setTotal(dto.getTotal());
        // Asigna el total desde el DTO.

        // Convierte el String metodoPago a enum MetodoPago si no es null.
        if (dto.getMetodoPago() != null) {
            compra.setMetodoPago(Compra.MetodoPago.valueOf(dto.getMetodoPago()));
        }

        return compra;
        // Devuelve la entidad poblada.
    }
}

