package mapeador;

import dto.ProductoDTO;
import modelo.Producto;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y usada en otros servicios o controladores.

public class ProductoMapeador {

    public ProductoDTO toDTO(Producto producto) {
        // Convierte una entidad Producto a su DTO ProductoDTO.

        if (producto == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        ProductoDTO dto = new ProductoDTO();
        // Crea una nueva instancia del DTO.

        dto.setId(producto.getId());
        dto.setNombre(producto.getNombre());
        dto.setDescripcion(producto.getDescripcion());
        dto.setPrecio(producto.getPrecio());
        dto.setStock(producto.getStock());
        // Copia los atributos básicos del producto.

        dto.setProveedorId(producto.getProveedor() != null ? producto.getProveedor().getId() : null);
        // Copia el ID del proveedor si existe; sino asigna null.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public Producto toEntidad(ProductoDTO dto) {
        // Convierte un DTO ProductoDTO a la entidad Producto.

        if (dto == null) return null;
        // Retorna null si el DTO es null.

        Producto producto = new Producto();
        // Crea una nueva instancia de la entidad.

        producto.setId(dto.getId());
        producto.setNombre(dto.getNombre());
        producto.setDescripcion(dto.getDescripcion());
        producto.setPrecio(dto.getPrecio());
        producto.setStock(dto.getStock());
        // Copia los atributos básicos del DTO a la entidad.

        // Para el proveedor, se debe asignar manualmente en el servicio si es necesario,
        // porque el DTO solo tiene el ID del proveedor, no el objeto completo.

        return producto;
        // Devuelve la entidad poblada.
    }
}

