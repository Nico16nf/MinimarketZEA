package mapeador;

import dto.UsuarioDTO;
import modelo.Usuario;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y utilizada en otros servicios o controladores.

public class UsuarioMapeador {

    public UsuarioDTO toDTO(Usuario usuario) {
        // Convierte una entidad Usuario a su DTO UsuarioDTO.

        if (usuario == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        UsuarioDTO dto = new UsuarioDTO();
        // Crea una nueva instancia del DTO.

        dto.setId(usuario.getId());
        dto.setNombreUsuario(usuario.getNombreUsuario());
        dto.setEmail(usuario.getEmail());
        dto.setRol(usuario.getRol());
        // Copia los atributos relevantes del usuario.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public Usuario toEntidad(UsuarioDTO dto) {
        // Convierte un DTO UsuarioDTO a la entidad Usuario.

        if (dto == null) return null;
        // Retorna null si el DTO es null.

        Usuario usuario = new Usuario();
        // Crea una nueva instancia de la entidad.

        usuario.setId(dto.getId());
        usuario.setNombreUsuario(dto.getNombreUsuario());
        usuario.setEmail(dto.getEmail());
        usuario.setRol(dto.getRol());
        // Copia los atributos relevantes del DTO a la entidad.

        return usuario;
        // Devuelve la entidad poblada.
    }
}

