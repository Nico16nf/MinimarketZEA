package mapeador;

import dto.ProveedorDTO;
import modelo.Proveedor;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y utilizada en otros servicios o controladores.

public class ProveedorMapeador {

    public ProveedorDTO toDTO(Proveedor proveedor) {
        // Convierte una entidad Proveedor a su DTO ProveedorDTO.

        if (proveedor == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        ProveedorDTO dto = new ProveedorDTO();
        // Crea una nueva instancia del DTO.

        dto.setId(proveedor.getId());
        dto.setNombre(proveedor.getNombre());
        dto.setContacto(proveedor.getContacto());
        // Copia los atributos básicos del proveedor.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public Proveedor toEntidad(ProveedorDTO dto) {
        // Convierte un DTO ProveedorDTO a la entidad Proveedor.

        if (dto == null) return null;
        // Retorna null si el DTO es null.

        Proveedor proveedor = new Proveedor();
        // Crea una nueva instancia de la entidad.

        proveedor.setId(dto.getId());
        proveedor.setNombre(dto.getNombre());
        proveedor.setContacto(dto.getContacto());
        // Copia los atributos básicos del DTO a la entidad.

        return proveedor;
        // Devuelve la entidad poblada.
    }
}

