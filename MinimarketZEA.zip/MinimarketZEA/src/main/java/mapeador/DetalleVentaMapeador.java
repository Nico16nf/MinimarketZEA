package mapeador;

import dto.DetalleVentaDTO;
import modelo.DetalleVenta;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y usada en otros servicios o controladores.

public class DetalleVentaMapeador {

    // Método para convertir una entidad DetalleVenta a su DTO DetalleVentaDTO.
    public DetalleVentaDTO toDTO(DetalleVenta detalleVenta) {
        if (detalleVenta == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        DetalleVentaDTO dto = new DetalleVentaDTO();
        // Crea una nueva instancia del DTO.

        dto.setProductoId(detalleVenta.getProducto().getId());
        // Copia el ID del producto asociado.

        dto.setNombreProducto(detalleVenta.getProducto().getNombre());
        // Copia el nombre del producto.

        dto.setCantidad(detalleVenta.getCantidad());
        // Copia la cantidad vendida.

        dto.setPrecioUnitario(detalleVenta.getPrecioUnitario());
        // Copia el precio unitario del producto.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    // Método para convertir un DTO DetalleVentaDTO a la entidad DetalleVenta.
    public DetalleVenta toEntidad(DetalleVentaDTO dto) {
        if (dto == null) return null;
        // Retorna null si el DTO es null para evitar errores.

        DetalleVenta detalleVenta = new DetalleVenta();
        // Crea una nueva instancia de la entidad.

        detalleVenta.setCantidad(dto.getCantidad());
        // Asigna la cantidad.

        detalleVenta.setPrecioUnitario(dto.getPrecioUnitario());
        // Asigna el precio unitario.

        // Nota: El objeto Producto debe ser asignado desde otro servicio o repositorio,
        // para evitar dependencias circulares o problemas de carga incompleta.

        return detalleVenta;
        // Devuelve la entidad poblada.
    }
}

