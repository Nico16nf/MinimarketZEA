package mapeador;

import dto.PagoDTO;
import modelo.Pago;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para poder inyectarla y usarla en otros servicios o controladores.

public class PagoMapeador {

    public PagoDTO toDTO(Pago pago) {
        // Convierte una entidad Pago a un DTO PagoDTO.

        if (pago == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        PagoDTO dto = new PagoDTO();
        // Crea una nueva instancia del DTO.

        dto.setCompraId(pago.getCompra() != null ? pago.getCompra().getId() : null);
        // Si la compra asociada no es null, copia su ID; si no, asigna null.

        // Convierte el enum TipoPago a su representación en String para el DTO.
        dto.setTipoPago(pago.getTipoPago() != null ? pago.getTipoPago().name() : null);

        dto.setNroOperacion(pago.getNroOperacion());
        // Copia el número de operación de la entidad al DTO.

        dto.setDatosCliente(pago.getDatosCliente());
        // Copia los datos adicionales del cliente.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public Pago toEntidad(PagoDTO dto) {
        // Convierte un DTO PagoDTO a la entidad Pago.

        if (dto == null) return null;
        // Retorna null si el DTO es null para evitar errores.

        Pago pago = new Pago();
        // Crea una nueva instancia de la entidad.

        // Convierte el String tipoPago a enum TipoPago si no es null.
        if (dto.getTipoPago() != null) {
            pago.setTipoPago(Pago.TipoPago.valueOf(dto.getTipoPago()));
        }

        pago.setNroOperacion(dto.getNroOperacion());
        // Asigna el número de operación desde el DTO.

        pago.setDatosCliente(dto.getDatosCliente());
        // Asigna los datos del cliente desde el DTO.

        return pago;
        // Devuelve la entidad poblada.
    }
}


