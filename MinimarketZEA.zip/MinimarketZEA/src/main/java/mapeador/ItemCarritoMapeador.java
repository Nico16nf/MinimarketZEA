package mapeador;

import dto.ItemCarritoDTO;
import modelo.ItemCarrito;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y utilizada en otros lugares.

public class ItemCarritoMapeador {

    public ItemCarritoDTO toDTO(ItemCarrito item) {
        // Convierte una entidad ItemCarrito a su DTO ItemCarritoDTO.

        if (item == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        ItemCarritoDTO dto = new ItemCarritoDTO();
        // Crea una nueva instancia del DTO.

        dto.setProductoId(item.getProducto() != null ? item.getProducto().getId() : null);
        // Si el producto asociado no es null, copia su ID; si no, asigna null.

        dto.setNombreProducto(item.getProducto() != null ? item.getProducto().getNombre() : null);
        // Similarmente, copia el nombre del producto si existe.

        dto.setCantidad(item.getCantidad());
        // Copia la cantidad del item en el carrito.

        dto.setPrecioUnitario(item.getProducto() != null ? item.getProducto().getPrecio() : null);
        // Copia el precio unitario si el producto existe.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public ItemCarrito toEntidad(ItemCarritoDTO dto) {
        // Convierte un DTO ItemCarritoDTO a la entidad ItemCarrito.

        if (dto == null) return null;
        // Retorna null si el DTO es null.

        ItemCarrito item = new ItemCarrito();
        // Crea una nueva instancia de la entidad.

        // Nota: El objeto Producto debe ser seteado en el servicio, buscándolo por su ID,
        // para evitar dependencias o carga incompleta en el mapper.

        item.setCantidad(dto.getCantidad());
        // Asigna la cantidad desde el DTO.

        return item;
        // Devuelve la entidad creada.
    }
}

