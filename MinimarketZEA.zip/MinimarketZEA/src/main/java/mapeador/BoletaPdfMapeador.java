package mapeador;

import dto.BoletaPdfDTO;
import modelo.BoletaPdf;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring, para que pueda ser inyectada y usada en otros lugares.

public class BoletaPdfMapeador {

    public BoletaPdfDTO toDTO(BoletaPdf boleta) {
        // Convierte una entidad BoletaPdf a su correspondiente DTO.

        if (boleta == null) return null;
        // Si la entidad es null, retorna null para evitar NullPointerException.

        BoletaPdfDTO dto = new BoletaPdfDTO();
        // Crea una nueva instancia del DTO.

        dto.setId(boleta.getId());
        // Copia el ID de la entidad al DTO.

        dto.setVentaId(boleta.getVenta() != null ? boleta.getVenta().getId() : null);
        // Copia el ID de la venta relacionada, si existe; sino pone null.

        dto.setArchivoPdf(boleta.getArchivoPdf());
        // Copia el contenido binario del PDF.

        return dto;
        // Devuelve el DTO ya lleno.
    }

    public BoletaPdf toEntidad(BoletaPdfDTO dto) {
        // Convierte un DTO BoletaPdfDTO a su entidad BoletaPdf correspondiente.

        if (dto == null) return null;
        // Si el DTO es null, retorna null para evitar errores.

        BoletaPdf boleta = new BoletaPdf();
        // Crea una nueva instancia de la entidad.

        boleta.setId(dto.getId());
        // Asigna el ID desde el DTO.

        boleta.setArchivoPdf(dto.getArchivoPdf());
        // Asigna el contenido binario del PDF.

        // Nota: La venta asociada debe ser asignada en el servicio, no aquí.
        // Esto es para evitar dependencias circulares o problemas de carga.

        return boleta;
        // Devuelve la entidad ya poblada.
    }
}
