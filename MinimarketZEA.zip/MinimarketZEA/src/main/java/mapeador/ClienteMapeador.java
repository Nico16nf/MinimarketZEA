package mapeador;

import dto.ClienteDTO;
import modelo.Cliente;
import org.springframework.stereotype.Component;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y usada en otros servicios o controladores.

public class ClienteMapeador {

    public ClienteDTO toDTO(Cliente cliente) {
        // Convierte una entidad Cliente a su correspondiente DTO ClienteDTO.

        if (cliente == null) return null;
        // Si la entidad es null, retorna null para evitar errores.

        ClienteDTO dto = new ClienteDTO();
        // Crea una nueva instancia del DTO.

        dto.setId(cliente.getId());
        dto.setNombre(cliente.getNombre());
        dto.setEmail(cliente.getEmail());
        dto.setTelefono(cliente.getTelefono());
        dto.setDireccion(cliente.getDireccion());
        // Copia cada atributo relevante de la entidad al DTO.

        return dto;
        // Devuelve el DTO con los datos copiados.
    }

    public Cliente toEntidad(ClienteDTO dto) {
        // Convierte un DTO ClienteDTO a la entidad Cliente correspondiente.

        if (dto == null) return null;
        // Si el DTO es null, retorna null para evitar errores.

        Cliente cliente = new Cliente();
        // Crea una nueva instancia de la entidad Cliente.

        cliente.setId(dto.getId());
        cliente.setNombre(dto.getNombre());
        cliente.setEmail(dto.getEmail());
        cliente.setTelefono(dto.getTelefono());
        cliente.setDireccion(dto.getDireccion());
        // Copia cada atributo relevante del DTO a la entidad.

        return cliente;
        // Devuelve la entidad con los datos copiados.
    }
}

