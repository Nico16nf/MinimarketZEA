package mapeador;

import dto.VentaDTO;
import dto.DetalleVentaDTO;
import modelo.Venta;
import org.springframework.stereotype.Component;
import java.util.List;
import java.util.stream.Collectors;

@Component
// Marca esta clase como un componente Spring para que pueda ser inyectada y usada en otros servicios o controladores.

public class VentaMapeador {

    private final DetalleVentaMapeador detalleVentaMapeador;
    // Dependencia para convertir entre DetalleVenta y DetalleVentaDTO.

    public VentaMapeador(DetalleVentaMapeador detalleVentaMapeador) {
        this.detalleVentaMapeador = detalleVentaMapeador;
    }
    // Constructor para inyección de dependencias (DetalleVentaMapeador).

    public VentaDTO toDTO(Venta venta) {
        // Convierte una entidad Venta a su DTO VentaDTO.

        if (venta == null) return null;
        // Retorna null si la entidad es null para evitar errores.

        VentaDTO dto = new VentaDTO();
        // Crea una nueva instancia del DTO.

        dto.setId(venta.getId());
        dto.setCompraId(venta.getCompra() != null ? venta.getCompra().getId() : null);
        dto.setFechaVenta(venta.getFechaVenta());
        dto.setTotal(venta.getTotal());
        // Copia los atributos básicos de la venta.

        // Convierte la lista de detalles de venta usando el mapper correspondiente.
        List<DetalleVentaDTO> detallesDto = venta.getDetalles().stream()
                .map(detalleVentaMapeador::toDTO)
                .collect(Collectors.toList());
        dto.setDetalles(detallesDto);

        return dto;
        // Devuelve el DTO con todos los datos copiados y transformados.
    }

    public Venta toEntidad(VentaDTO dto) {
        // Convierte un DTO VentaDTO a la entidad Venta.

        if (dto == null) return null;
        // Retorna null si el DTO es null.

        Venta venta = new Venta();
        // Crea una nueva instancia de la entidad.

        venta.setId(dto.getId());
        venta.setFechaVenta(dto.getFechaVenta());
        venta.setTotal(dto.getTotal());
        // Copia los atributos básicos.

        // Nota: La asignación de la compra y detalles puede realizarse en la capa de servicio,
        // ya que puede requerir acceso a repositorios o lógica adicional.

        return venta;
        // Devuelve la entidad poblada.
    }
}

