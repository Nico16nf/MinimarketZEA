package org.example.minimarketzea;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MinimarketZeaApplication {

    public static void main(String[] args) {
        SpringApplication.run(MinimarketZeaApplication.class, args);
    }

}
