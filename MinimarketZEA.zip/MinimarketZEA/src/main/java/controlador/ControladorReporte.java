package controlador;

import modelo.Compra;
import servicio.ServicioReporte;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
// Define esta clase como un controlador REST, para que sus métodos devuelvan respuestas JSON automáticamente.

public class ControladorReporte {

    private final ServicioReporte servicioReporte;
    // Servicio inyectado que contiene la lógica para generar los reportes.

    public ControladorReporte(ServicioReporte servicioReporte) {
        this.servicioReporte = servicioReporte;
    }
    // Constructor para inyectar el servicioReporte mediante inyección de dependencias.

    // Endpoint para obtener reporte de compras por cliente
    @GetMapping("/api/reportes/compras")
    // Este método responde a peticiones HTTP GET en la ruta "/api/reportes/compras".

    public ResponseEntity<List<Compra>> generarReporteCompras(@RequestParam Long clienteId) {
        // Recibe el parámetro 'clienteId' como parámetro de consulta (?clienteId=valor).

        // Llama al servicio para obtener la lista de compras realizadas por ese cliente.
        List<Compra> compras = servicioReporte.generarReporteComprasPorCliente(clienteId);

        // Si la lista de compras está vacía...
        if (compras.isEmpty()) {
            // ...devuelve un código HTTP 204 No Content (sin cuerpo).
            return ResponseEntity.noContent().build();
        }

        // Si hay compras, devuelve la lista con código HTTP 200 OK.
        return ResponseEntity.ok(compras);
    }

    // Endpoint para obtener reporte de compras por estado
    @GetMapping("/api/reportes/compras/estado")
    // Este método responde a peticiones HTTP GET en la ruta "/api/reportes/compras/estado".

    public ResponseEntity<List<Compra>> generarReporteComprasPorEstado(@RequestParam String estado) {
        // Recibe el parámetro 'estado' para filtrar compras por su estado (ejemplo: "pendiente", "pagado", etc.).

        // Llama al servicio para obtener la lista de compras con ese estado.
        List<Compra> compras = servicioReporte.generarReporteComprasPorEstado(estado);

        // Si no hay compras con ese estado...
        if (compras.isEmpty()) {
            // ...devuelve HTTP 204 No Content.
            return ResponseEntity.noContent().build();
        }

        // Si hay compras, devuelve la lista con código HTTP 200 OK.
        return ResponseEntity.ok(compras);
    }
}

