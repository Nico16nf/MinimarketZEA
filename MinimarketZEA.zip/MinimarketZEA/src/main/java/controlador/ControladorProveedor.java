package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
// Indica que esta clase es un controlador REST, que devuelve respuestas JSON automáticamente.

@RequestMapping("/api/proveedores")
// Establece la ruta base para todos los endpoints de este controlador: "/api/proveedores".

public class ControladorProveedor {

    @GetMapping
    // Define que este método responde a solicitudes HTTP GET en "/api/proveedores" (sin más ruta).

    public ResponseEntity<List</*ProveedorDTO*/ Object>> listarProveedores() {
        // Aquí debería retornar la lista de proveedores (idealmente una lista de DTOs).
        // Actualmente retorna una lista vacía (List.of()) para simular.

        return ResponseEntity.ok(List.of(/* proveedores */));
        // Responde con HTTP 200 OK y el cuerpo con la lista de proveedores.
    }

    @PostMapping
    // Define que este método responde a solicitudes HTTP POST en "/api/proveedores".

    public ResponseEntity<?> registrarProveedor(@RequestBody /*ProveedorDTO*/ Object proveedorDto) {
        // Recibe un objeto JSON con los datos del nuevo proveedor para registrar.
        // Aquí iría la lógica para guardar el proveedor.

        return ResponseEntity.ok("Proveedor registrado");
        // Devuelve HTTP 200 OK con mensaje de confirmación.
    }

    @PutMapping("/{id}")
    // Define que este método responde a solicitudes HTTP PUT en "/api/proveedores/{id}" para actualizar un proveedor específico.

    public ResponseEntity<?> actualizarProveedor(@PathVariable Long id, @RequestBody /*ProveedorDTO*/ Object proveedorDto) {
        // Recibe el id del proveedor a actualizar por URL y los nuevos datos en el cuerpo.
        // Aquí iría la lógica para actualizar el proveedor con ese id.

        return ResponseEntity.ok("Proveedor actualizado");
        // Devuelve HTTP 200 OK con mensaje de confirmación.
    }

    @DeleteMapping("/{id}")
    // Define que este método responde a solicitudes HTTP DELETE en "/api/proveedores/{id}" para eliminar un proveedor.

    public ResponseEntity<?> eliminarProveedor(@PathVariable Long id) {
        // Recibe el id del proveedor a eliminar.
        // Aquí iría la lógica para eliminar el proveedor.

        return ResponseEntity.ok("Proveedor eliminado");
        // Devuelve HTTP 200 OK con mensaje de confirmación.
    }
}
