package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// Marca esta clase como un controlador REST que maneja respuestas JSON automáticamente.

@RequestMapping("/api/pagos")
// Establece la ruta base para este controlador, que es "/api/pagos".

public class ControladorPago {

    @PostMapping("/confirmar")
    // Define que este método responde a solicitudes HTTP POST en la ruta "/api/pagos/confirmar".

    public ResponseEntity<?> confirmarPago(@RequestBody /*PagoDTO*/ Object pagoDto) {
        // Recibe en el cuerpo de la petición un objeto JSON con los datos del pago (aquí como Object temporalmente).
        // Aquí se validaría el número de operación y demás datos para confirmar el pago.

        return ResponseEntity.ok("Pago confirmado");
        // Responde con HTTP 200 OK y un mensaje que confirma que el pago fue validado exitosamente.
    }
}

