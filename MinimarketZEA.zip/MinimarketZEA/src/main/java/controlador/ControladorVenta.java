package controlador;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import java.io.ByteArrayInputStream;
import java.io.IOException;

@RestController
// Define esta clase como un controlador REST que responde con JSON o datos binarios según el caso.

public class ControladorVenta {

    // Ejemplo: Método para devolver un archivo PDF
    @GetMapping("/api/venta/{id}/pdf")
    // Método que atiende solicitudes GET en la ruta "/api/venta/{id}/pdf" para descargar un PDF.

    public ResponseEntity<byte[]> generarPDFVenta(Long id) throws IOException {
        // Recibe un parámetro 'id' (aunque aquí falta la anotación para recibirlo desde la ruta).
        // El método puede lanzar IOException en caso de error en generación del PDF.

        // Aquí se llama a un método que genera el PDF y lo devuelve como un arreglo de bytes.
        byte[] archivoPdf = generarPdf();

        // Configura los encabezados HTTP para la respuesta.
        HttpHeaders headers = new HttpHeaders();
        headers.add("Content-Disposition", "attachment; filename=venta_" + id + ".pdf");
        // El encabezado Content-Disposition indica que la respuesta es un archivo adjunto con nombre personalizado.

        // Devuelve la respuesta con estado 200 OK, los encabezados, el tipo de contenido PDF y el cuerpo con el archivo.
        return ResponseEntity.ok()
                .headers(headers)
                .contentType(MediaType.APPLICATION_PDF)  // Indica que el contenido es un PDF.
                .body(archivoPdf);  // Envía los bytes del archivo PDF.
    }

    // Método ficticio que simula la generación del PDF como un arreglo de bytes.
    private byte[] generarPdf() {
        // Aquí iría la lógica para crear el PDF usando iText o alguna librería similar.
        return new byte[0];  // Por ahora devuelve un arreglo vacío.
    }
}


