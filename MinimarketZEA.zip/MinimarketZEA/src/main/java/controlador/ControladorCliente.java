package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// Marca esta clase como un controlador REST, para que los métodos devuelvan JSON automáticamente.

@RequestMapping("/api/clientes")
// Define la ruta base para todos los endpoints de este controlador, en este caso "/api/clientes".

public class ControladorCliente {

    @PostMapping("/registro")
    // Define que este método responde a solicitudes HTTP POST en la ruta "/api/clientes/registro".

    public ResponseEntity<?> registrarCliente(@RequestBody /*ClienteDTO*/ Object clienteDto) {
        // Recibe un objeto JSON en el cuerpo de la petición, que debería mapearse a un DTO de cliente (aquí es Object temporalmente).
        // Aquí iría la lógica para registrar un nuevo cliente en la base de datos.

        return ResponseEntity.ok("Cliente registrado");
        // Devuelve una respuesta HTTP 200 OK con un mensaje simple de confirmación.
    }

    @PutMapping("/{id}")
    // Define que este método responde a solicitudes HTTP PUT en la ruta "/api/clientes/{id}", donde {id} es el identificador del cliente.

    public ResponseEntity<?> actualizarCliente(@PathVariable Long id, @RequestBody /*ClienteDTO*/ Object clienteDto) {
        // Recibe el id del cliente a actualizar vía URL y los datos nuevos vía cuerpo JSON.
        // Aquí iría la lógica para actualizar el cliente con ese id.

        return ResponseEntity.ok("Cliente actualizado");
        // Devuelve una respuesta HTTP 200 OK con mensaje de confirmación.
    }
}
