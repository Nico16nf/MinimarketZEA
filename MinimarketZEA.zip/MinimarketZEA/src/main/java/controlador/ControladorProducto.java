package controlador;

import modelo.Producto;
import servicio.ServicioProducto;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
// Esta clase es un controlador REST, es decir, atiende peticiones HTTP y devuelve respuestas en formato JSON.

public class ControladorProducto {

    private final ServicioProducto servicioProducto;
    // Se declara una dependencia llamada servicioProducto que maneja la lógica relacionada a productos.

    public ControladorProducto(ServicioProducto servicioProducto) {
        this.servicioProducto = servicioProducto;
    }
    // Constructor que recibe el servicioProducto para inicializar la dependencia (inyección por constructor).

    // Endpoint para obtener todos los productos
    @GetMapping("/api/productos")
    // Método que responde a solicitudes HTTP GET en la ruta "/api/productos".

    public ResponseEntity<List<Producto>> obtenerTodosLosProductos() {
        List<Producto> productos = servicioProducto.listarTodos();
        // Se llama al servicio para obtener una lista de todos los productos.

        // Si no hay productos, devolvemos 204 No Content
        if (productos.isEmpty()) {
            return ResponseEntity.noContent().build();
            // Si la lista está vacía, responde con código HTTP 204 (sin contenido).
        }

        // Devolver productos con el estado 200 OK
        return ResponseEntity.ok(productos);
        // Si hay productos, responde con código HTTP 200 y envía la lista en el cuerpo.
    }

    // Endpoint para obtener un producto por ID
    @GetMapping("/api/productos/{id}")
    // Método que responde a solicitudes HTTP GET en la ruta "/api/productos/{id}".
    // {id} se espera que sea una variable dinámica que indique el id del producto a buscar.

    public ResponseEntity<Producto> obtenerProductoPorId(@RequestParam Long id) {
        // Aquí se recibe el parámetro "id" desde la URL, pero usando @RequestParam (lo que indica que espera ?id=valor en query, no en la ruta).

        Producto producto = servicioProducto.obtenerPorId(id);
        // Se llama al servicio para buscar el producto con el id recibido.

        // Si no existe el producto, devolvemos 404 Not Found
        if (producto == null) {
            return ResponseEntity.notFound().build();
            // Si no se encontró el producto, responde con código HTTP 404.
        }

        // Devolver producto con el estado 200 OK
        return ResponseEntity.ok(producto);
        // Si el producto existe, responde con código HTTP 200 y envía el producto en el cuerpo.
    }
}

