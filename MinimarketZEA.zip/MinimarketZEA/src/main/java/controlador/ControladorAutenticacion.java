package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// Indica que esta clase es un controlador REST y que los métodos devuelven respuestas JSON automáticamente.

@RequestMapping("/api/auth")
// Define la ruta base para todas las peticiones de este controlador, en este caso, "/api/auth".

public class ControladorAutenticacion {

    @PostMapping("/login")
    // Define que este método responde a peticiones HTTP POST a la ruta "/api/auth/login".

    public ResponseEntity<?> login(@RequestBody /*LoginDTO*/ Object loginDto) {
        // Recibe en el cuerpo de la petición un objeto JSON que se mapeará al DTO de login (aquí está como Object temporalmente).
        // Aquí iría la lógica para autenticar al usuario con los datos recibidos y generar un token JWT.

        return ResponseEntity.ok("Token JWT");
        // Retorna una respuesta HTTP 200 OK con el token JWT como texto (simulado aquí).
    }

    @PostMapping("/registro")
    // Define que este método responde a peticiones HTTP POST a la ruta "/api/auth/registro".

    public ResponseEntity<?> registrarUsuario(@RequestBody /*RegistroDTO*/ Object registroDto) {
        // Recibe en el cuerpo de la petición un objeto JSON que se mapeará al DTO de registro de usuario (temporalmente Object).
        // Aquí iría la lógica para crear un nuevo usuario en el sistema.

        return ResponseEntity.ok("Usuario registrado");
        // Retorna una respuesta HTTP 200 OK con un mensaje de confirmación de registro.
    }
}
