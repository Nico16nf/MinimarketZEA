package controlador;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
// Define esta clase como un controlador REST, que devuelve respuestas JSON automáticamente.

@RequestMapping("/api/compras")
// Establece la ruta base para todos los endpoints de este controlador, en este caso "/api/compras".

public class ControladorCompra {

    @PostMapping("/finalizar")
    // Define que este método responde a peticiones HTTP POST a la ruta "/api/compras/finalizar".

    public ResponseEntity<?> finalizarCompra(@RequestBody /*CompraDTO*/ Object compraDto) {
        // Recibe en el cuerpo de la petición un objeto JSON que representa los datos de la compra.
        // Aquí se procesaría la compra, incluyendo la selección del método de pago (Yape o transferencia).

        return ResponseEntity.ok("Compra registrada. Proceda con el pago.");
        // Devuelve una respuesta HTTP 200 OK con un mensaje indicando que la compra fue registrada y el siguiente paso es realizar el pago.
    }
}
