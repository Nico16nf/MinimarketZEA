package controlador;

import modelo.ItemCarrito;
import servicio.ServicioCarrito;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import java.util.List;

@RestController
// Indica que esta clase es un controlador REST y sus métodos devolverán respuestas JSON automáticamente.

public class ControladorCarrito {

    private final ServicioCarrito servicioCarrito;
    // Declaración de la dependencia al servicio que maneja la lógica del carrito.

    public ControladorCarrito(ServicioCarrito servicioCarrito) {
        this.servicioCarrito = servicioCarrito;
    }
    // Constructor para inyectar el servicio de carrito mediante inyección de dependencias (por ejemplo, con Spring).

    // Ejemplo de endpoint para obtener los items del carrito
    @GetMapping("/api/carrito")
    // Define que este método responde a solicitudes HTTP GET en la ruta "/api/carrito".

    public ResponseEntity<List<ItemCarrito>> obtenerItemsCarrito(@RequestParam Long clienteId) {
        // Método que recibe como parámetro obligatorio "clienteId" vía query string (?clienteId=123).

        // Llamada al servicio para obtener la lista de items del carrito según el cliente.
        List<ItemCarrito> itemsCarrito = servicioCarrito.obtenerCarritoPorCliente(clienteId);

        // Verifica si la lista está vacía (sin items)
        if (itemsCarrito.isEmpty()) {
            return ResponseEntity.noContent().build();
            // Si no hay items, responde con código HTTP 204 No Content, sin cuerpo.
        }

        // Si hay items, responde con código HTTP 200 OK y devuelve la lista en el cuerpo de la respuesta.
        return ResponseEntity.ok(itemsCarrito);
    }
}

