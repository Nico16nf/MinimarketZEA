package dto;

import java.time.LocalDateTime;
import java.util.List;

public class VentaDTO {
    private Long id;
    // Identificador único de la venta.

    private Long compraId;
    // Referencia a la compra asociada a esta venta.

    private LocalDateTime fechaVenta;
    // Fecha y hora en que se realizó la venta.

    private Double total;
    // Total monetario de la venta.

    private List<DetalleVentaDTO> detalles;
    // Lista de detalles o productos vendidos en esta venta.

    public VentaDTO() {}
    // Constructor vacío para frameworks que utilizan reflexión.

    // Getters y setters para cada atributo:

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getCompraId() { return compraId; }
    public void setCompraId(Long compraId) { this.compraId = compraId; }

    public LocalDateTime getFechaVenta() { return fechaVenta; }
    public void setFechaVenta(LocalDateTime fechaVenta) { this.fechaVenta = fechaVenta; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public List<DetalleVentaDTO> getDetalles() { return detalles; }
    public void setDetalles(List<DetalleVentaDTO> detalles) { this.detalles = detalles; }
}
