package dto;

public class PagoDTO {
    private Long compraId;
    // Identificador de la compra a la que corresponde el pago.

    private String tipoPago;
    // Tipo de pago realizado, por ejemplo: "YAPE" o "TRANSFERENCIA".

    private String nroOperacion;
    // Número de operación o referencia de la transacción (recibo, código, etc.).

    private String datosCliente;
    // Información adicional del cliente, puede ser opcional (por ejemplo, nombre, teléfono).

    public PagoDTO() {}
    // Constructor vacío para frameworks que usan reflexión.

    // Getters y setters para acceder y modificar cada campo:

    public Long getCompraId() { return compraId; }
    public void setCompraId(Long compraId) { this.compraId = compraId; }

    public String getTipoPago() { return tipoPago; }
    public void setTipoPago(String tipoPago) { this.tipoPago = tipoPago; }

    public String getNroOperacion() { return nroOperacion; }
    public void setNroOperacion(String nroOperacion) { this.nroOperacion = nroOperacion; }

    public String getDatosCliente() { return datosCliente; }
    public void setDatosCliente(String datosCliente) { this.datosCliente = datosCliente; }
}
