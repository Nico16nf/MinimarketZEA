package dto;

public class ItemCarritoDTO {
    private Long productoId;
    // Identificador único del producto en el carrito.

    private String nombreProducto; // opcional para mostrar
    // Nombre o descripción del producto, útil para mostrar en la interfaz.

    private Integer cantidad;
    // Cantidad del producto que el cliente ha agregado al carrito.

    private Double precioUnitario; // opcional
    // Precio unitario del producto, también útil para mostrar.

    public ItemCarritoDTO() {}
    // Constructor vacío necesario para frameworks que usan reflexión para instanciar.

    // Getters y setters para cada campo:

    public Long getProductoId() { return productoId; }
    public void setProductoId(Long productoId) { this.productoId = productoId; }

    public String getNombreProducto() { return nombreProducto; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public Double getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(Double precioUnitario) { this.precioUnitario = precioUnitario; }
}
