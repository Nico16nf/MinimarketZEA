package dto;

public class BoletaPdfDTO {
    private Long id;
    // Identificador único de la boleta PDF (podría ser el ID en base de datos).

    private Long ventaId;
    // Identificador de la venta asociada a esta boleta.

    private byte[] archivoPdf;
    // Contenido binario del archivo PDF, almacenado como arreglo de bytes.

    public BoletaPdfDTO() {}
    // Constructor vacío necesario para frameworks que requieren instancia sin argumentos.

    // Getters y setters para acceder y modificar los atributos.

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Long getVentaId() { return ventaId; }
    public void setVentaId(Long ventaId) { this.ventaId = ventaId; }

    public byte[] getArchivoPdf() { return archivoPdf; }
    public void setArchivoPdf(byte[] archivoPdf) { this.archivoPdf = archivoPdf; }
}
