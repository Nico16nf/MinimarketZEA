package dto;

public class DetalleVentaDTO {
    private Long productoId;
    // Identificador único del producto vendido.

    private String nombreProducto;
    // Nombre o descripción del producto.

    private Integer cantidad;
    // Cantidad de unidades vendidas de este producto.

    private Double precioUnitario;
    // Precio unitario de cada producto vendido.

    public DetalleVentaDTO() {}
    // Constructor vacío para frameworks que requieren instanciación vía reflexión.

    // Getters y setters para cada campo:

    public Long getProductoId() { return productoId; }
    public void setProductoId(Long productoId) { this.productoId = productoId; }

    public String getNombreProducto() { return nombreProducto; }
    public void setNombreProducto(String nombreProducto) { this.nombreProducto = nombreProducto; }

    public Integer getCantidad() { return cantidad; }
    public void setCantidad(Integer cantidad) { this.cantidad = cantidad; }

    public Double getPrecioUnitario() { return precioUnitario; }
    public void setPrecioUnitario(Double precioUnitario) { this.precioUnitario = precioUnitario; }
}
