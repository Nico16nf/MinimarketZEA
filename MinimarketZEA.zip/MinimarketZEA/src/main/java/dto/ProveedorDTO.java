package dto;

public class ProveedorDTO {
    private Long id;
    // Identificador único del proveedor.

    private String nombre;
    // Nombre o razón social del proveedor.

    private String contacto;
    // Información de contacto del proveedor, que puede ser un correo electrónico o un número de teléfono.

    public ProveedorDTO() {}
    // Constructor vacío necesario para frameworks que crean instancias mediante reflexión.

    // Getters y setters para acceder y modificar los campos:

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getContacto() { return contacto; }
    public void setContacto(String contacto) { this.contacto = contacto; }
}


