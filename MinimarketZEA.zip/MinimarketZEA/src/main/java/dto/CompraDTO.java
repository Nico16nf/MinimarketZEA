package dto;

public class CompraDTO {
    private Long clienteId;
    // Identificador del cliente que realiza la compra.

    private Double total;
    // Monto total de la compra.

    private String metodoPago;
    // Método de pago usado para la compra, por ejemplo: "YAPE" o "TRANSFERENCIA".

    public CompraDTO() {}
    // Constructor vacío necesario para frameworks que usan reflexión.

    // Getters y setters para cada campo:

    public Long getClienteId() { return clienteId; }
    public void setClienteId(Long clienteId) { this.clienteId = clienteId; }

    public Double getTotal() { return total; }
    public void setTotal(Double total) { this.total = total; }

    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
}
