package configuracion;

import jakarta.persistence.EntityManagerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import javax.sql.DataSource;
import java.util.Properties;

@Configuration
// Indica que esta clase contiene configuraciones de Spring y define beans para el contexto de la aplicación.
public class BasedeDatos {

    @Value("${spring.datasource.url}")
    // Inyecta el valor de la propiedad 'spring.datasource.url' desde el archivo de configuración (application.properties o application.yml).
    private String dbUrl;

    @Value("${spring.datasource.username}")
    // Inyecta el valor de la propiedad 'spring.datasource.username'.
    private String dbUser;

    @Value("${spring.datasource.password}")
    // Inyecta el valor de la propiedad 'spring.datasource.password'.
    private String dbPass;

    @Value("${spring.datasource.driver-class-name}")
    // Inyecta el valor del driver JDBC que se usará para conectar a la base de datos.
    private String dbDriver;

    @Bean
    // Define un bean en el contexto de Spring llamado 'dataSource'.
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        // Crea una instancia de DriverManagerDataSource para gestionar conexiones JDBC.

        dataSource.setDriverClassName(dbDriver);
        // Establece la clase del driver JDBC.

        dataSource.setUrl(dbUrl);
        // Configura la URL para conectarse a la base de datos.

        dataSource.setUsername(dbUser);
        // Configura el usuario para la conexión.

        dataSource.setPassword(dbPass);
        // Configura la contraseña para la conexión.

        System.out.println("Conexion a base de datos establecida con exito.");
        // Muestra un mensaje en consola indicando que se estableció la conexión (aunque solo se configura el datasource, la conexión real se realiza luego).

        return dataSource;
        // Devuelve el datasource configurado para ser usado por Spring.
    }

    @Bean
    // Define un bean que será el EntityManagerFactory de JPA para manejar las entidades y persistencia.
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean emf = new LocalContainerEntityManagerFactoryBean();
        // Crea la fábrica de EntityManager para manejar la persistencia.

        emf.setDataSource(dataSource());
        // Asocia el DataSource configurado previamente para que JPA use esa conexión.

        emf.setPackagesToScan("com.empress.minimarket.modelo");
        // Define el paquete donde están las entidades JPA para que las detecte y gestione automáticamente.

        emf.setJpaVendorAdapter(new HibernateJpaVendorAdapter());
        // Configura Hibernate como proveedor JPA.

        Properties jpaProperties = new Properties();
        // Crea un conjunto de propiedades específicas para JPA/Hibernate.

        jpaProperties.put("hibernate.dialect", "org.hibernate.dialect.MySQL8Dialect");
        // Indica el dialecto de SQL para MySQL 8, para que Hibernate genere el SQL adecuado.

        jpaProperties.put("hibernate.show_sql", "true");
        // Activa que se muestre el SQL generado por Hibernate en consola para debug.

        jpaProperties.put("hibernate.hbm2ddl.auto", "update");
        // Configura que Hibernate actualice la base de datos automáticamente según los cambios en las entidades (sin borrar datos).

        emf.setJpaProperties(jpaProperties);
        // Aplica las propiedades configuradas al EntityManagerFactory.

        return emf;
        // Devuelve el bean configurado del EntityManagerFactory.
    }

    @Bean
    // Define un bean para gestionar las transacciones JPA de Spring.
    public JpaTransactionManager transactionManager(EntityManagerFactory emf) {
        JpaTransactionManager txManager = new JpaTransactionManager();
        // Crea un administrador de transacciones para JPA.

        txManager.setEntityManagerFactory(emf);
        // Asocia el EntityManagerFactory para que el transaction manager controle las transacciones de esta fábrica.

        return txManager;
        // Devuelve el transaction manager configurado.
    }

    @Bean
    // Define un bean que traduce las excepciones nativas de JPA en excepciones propias de Spring.
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
        // Este bean intercepta las excepciones lanzadas por JPA y las convierte en excepciones más manejables y específicas de Spring.
    }

    // Comentario final:
    // Este bean facilita el manejo de errores en la capa de persistencia, para que los desarrolladores trabajen con excepciones estándar de Spring.
}

