package excepcion;

public class SolicitudIncorrectaException extends RuntimeException {
    // Esta clase define una excepción personalizada que extiende RuntimeException.
    // Se usa para indicar que una solicitud HTTP es incorrecta o inválida (error 400).

    public SolicitudIncorrectaException() {
        super();
        // Constructor por defecto que llama al constructor sin argumentos de RuntimeException.
    }

    public SolicitudIncorrectaException(String mensaje) {
        super(mensaje);
        // Constructor que recibe un mensaje personalizado y lo pasa al constructor de RuntimeException.
        // Este mensaje puede ser usado para describir el error específico.
    }
}

