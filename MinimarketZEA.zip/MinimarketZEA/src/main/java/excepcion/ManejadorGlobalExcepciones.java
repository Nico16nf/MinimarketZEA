package excepcion;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@ControllerAdvice
// Marca esta clase como un manejador global de excepciones para todos los controladores REST.
// Intercepta las excepciones lanzadas y permite definir respuestas personalizadas.

public class ManejadorGlobalExcepciones {

    @ExceptionHandler(RecursoNoEncontradoException.class)
    // Maneja específicamente excepciones de tipo RecursoNoEncontradoException.

    public ResponseEntity<Object> manejarRecursoNoEncontrado(RecursoNoEncontradoException ex) {
        Map<String, Object> body = new HashMap<>();
        // Crea un mapa para la respuesta JSON que contendrá información del error.

        body.put("timestamp", LocalDateTime.now());
        // Añade la fecha y hora actual para registrar cuándo ocurrió el error.

        body.put("mensaje", ex.getMessage() != null ? ex.getMessage() : "Recurso no encontrado");
        // Usa el mensaje de la excepción si está presente, sino un mensaje genérico.

        body.put("estado", HttpStatus.NOT_FOUND.value());
        // Código HTTP 404 para recurso no encontrado.

        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
        // Retorna la respuesta con el cuerpo y código 404.
    }

    @ExceptionHandler(SolicitudIncorrectaException.class)
    // Maneja excepciones de tipo SolicitudIncorrectaException.

    public ResponseEntity<Object> manejarSolicitudIncorrecta(SolicitudIncorrectaException ex) {
        Map<String, Object> body = new HashMap<>();

        body.put("timestamp", LocalDateTime.now());

        body.put("mensaje", ex.getMessage() != null ? ex.getMessage() : "Solicitud incorrecta");
        // Mensaje personalizado o genérico para error 400 Bad Request.

        body.put("estado", HttpStatus.BAD_REQUEST.value());

        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }

    @ExceptionHandler(Exception.class)
    // Captura cualquier otra excepción no manejada específicamente (genérica).

    public ResponseEntity<Object> manejarExcepcionGenerica(Exception ex) {
        Map<String, Object> body = new HashMap<>();

        body.put("timestamp", LocalDateTime.now());

        body.put("mensaje", "Error interno del servidor");
        // Mensaje genérico para errores inesperados.

        body.put("detalle", ex.getMessage());
        // Detalle con el mensaje original de la excepción.

        body.put("estado", HttpStatus.INTERNAL_SERVER_ERROR.value());
        // Código HTTP 500 Internal Server Error.

        return new ResponseEntity<>(body, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}
