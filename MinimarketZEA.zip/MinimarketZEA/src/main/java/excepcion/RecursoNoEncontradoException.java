package excepcion;

public class RecursoNoEncontradoException extends RuntimeException {
    // Esta clase define una excepción personalizada que extiende RuntimeException.
    // Se usa para indicar que un recurso no fue encontrado (equivalente a un error 404).

    public RecursoNoEncontradoException() {
        super();
        // Constructor por defecto que llama al constructor sin argumentos de RuntimeException.
    }

    public RecursoNoEncontradoException(String mensaje) {
        super(mensaje);
        // Constructor que recibe un mensaje personalizado y lo pasa al constructor de RuntimeException.
        // Este mensaje podrá ser recuperado con getMessage() para mostrar detalles del error.
    }
}
