package modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "producto")
// Define el nombre de la tabla en la base de datos como "producto".

public class Producto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único del producto.

    private String nombre;
    // Nombre del producto.

    private String descripcion;
    // Descripción o detalles del producto.

    private Double precio;
    // Precio unitario del producto.

    private Integer stock;
    // Cantidad disponible en inventario.

    @ManyToOne
    @JoinColumn(name = "proveedor_id")
    // Relación muchos a uno con la entidad Proveedor, usando la columna "proveedor_id".

    private Proveedor proveedor;
    // Proveedor asociado a este producto.

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Double getPrecio() {
        return precio;
    }

    public void setPrecio(Double precio) {
        this.precio = precio;
    }

    public Integer getStock() {
        return stock;
    }

    public void setStock(Integer stock) {
        this.stock = stock;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public void setProveedor(Proveedor proveedor) {
        this.proveedor = proveedor;
    }
}
