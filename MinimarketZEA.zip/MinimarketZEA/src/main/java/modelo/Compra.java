package modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "compra")
// Define el nombre de la tabla en la base de datos como "compra".

public class Compra {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como la clave primaria con valor autogenerado (auto-increment).

    private Long id;
    // Identificador único de la compra.

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    // Define una relación muchos a uno con la entidad Cliente, usando la columna "cliente_id".

    private Cliente cliente;
    // Cliente asociado a esta compra.

    private LocalDateTime fecha;
    // Fecha y hora en que se realizó la compra.

    private Double total;
    // Monto total de la compra.

    @Enumerated(EnumType.STRING)
    // Indica que el campo enum EstadoCompra se almacenará como texto en la base de datos.

    private EstadoCompra estado;
    // Estado actual de la compra (PENDIENTE, PAGADO, CANCELADO).

    @Enumerated(EnumType.STRING)
    // El enum MetodoPago se almacenará como texto.

    private MetodoPago metodoPago;
    // Método de pago usado (YAPE o TRANSFERENCIA).

    // Enumeraciones internas que definen los valores posibles para estado y método de pago.

    public enum EstadoCompra {
        PENDIENTE, PAGADO, CANCELADO
    }

    public enum MetodoPago {
        YAPE, TRANSFERENCIA
    }

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public void setFecha(LocalDateTime fecha) {
        this.fecha = fecha;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public EstadoCompra getEstado() {
        return estado;
    }

    public void setEstado(EstadoCompra estado) {
        this.estado = estado;
    }

    public MetodoPago getMetodoPago() {
        return metodoPago;
    }

    public void setMetodoPago(MetodoPago metodoPago) {
        this.metodoPago = metodoPago;
    }
}
