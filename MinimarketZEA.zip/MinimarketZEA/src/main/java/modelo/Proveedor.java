package modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "proveedor")
// Define el nombre de la tabla en la base de datos como "proveedor".

public class Proveedor {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único del proveedor.

    private String nombre;
    // Nombre o razón social del proveedor.

    private String contacto;
    // Información de contacto, puede ser un correo electrónico o teléfono.

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getContacto() {
        return contacto;
    }

    public void setContacto(String contacto) {
        this.contacto = contacto;
    }
}

