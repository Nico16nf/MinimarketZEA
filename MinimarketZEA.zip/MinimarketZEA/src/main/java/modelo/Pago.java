package modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "pago")
// Define el nombre de la tabla en la base de datos como "pago".

public class Pago {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único del pago.

    @ManyToOne
    @JoinColumn(name = "compra_id")
    // Relación muchos a uno con la entidad Compra, usando la columna "compra_id".

    private Compra compra;
    // Compra a la que pertenece este pago.

    @Enumerated(EnumType.STRING)
    // El enum TipoPago se almacena como texto en la base de datos.

    private TipoPago tipoPago;
    // Tipo de pago, por ejemplo, YAPE o TRANSFERENCIA.

    private String nroOperacion;
    // Número de operación o referencia de la transacción.

    private String datosCliente;
    // Datos adicionales del cliente (pueden ser opcionales).

    private LocalDateTime fechaPago;
    // Fecha y hora en que se realizó el pago.

    @Enumerated(EnumType.STRING)
    // El enum EstadoPago se almacena como texto.

    private EstadoPago estadoPago;
    // Estado del pago (PENDIENTE o CONFIRMADO).

    // Definición de los enums usados para TipoPago y EstadoPago.

    public enum TipoPago {
        YAPE, TRANSFERENCIA
    }

    public enum EstadoPago {
        PENDIENTE, CONFIRMADO
    }

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public TipoPago getTipoPago() {
        return tipoPago;
    }

    public void setTipoPago(TipoPago tipoPago) {
        this.tipoPago = tipoPago;
    }

    public String getNroOperacion() {
        return nroOperacion;
    }

    public void setNroOperacion(String nroOperacion) {
        this.nroOperacion = nroOperacion;
    }

    public String getDatosCliente() {
        return datosCliente;
    }

    public void setDatosCliente(String datosCliente) {
        this.datosCliente = datosCliente;
    }

    public LocalDateTime getFechaPago() {
        return fechaPago;
    }

    public void setFechaPago(LocalDateTime fechaPago) {
        this.fechaPago = fechaPago;
    }

    public EstadoPago getEstadoPago() {
        return estadoPago;
    }

    public void setEstadoPago(EstadoPago estadoPago) {
        this.estadoPago = estadoPago;
    }
}
