package modelo;

import jakarta.persistence.*;

@Entity
// Marca esta clase como una entidad JPA que será mapeada a una tabla en la base de datos.

@Table(name = "cliente")
// Define el nombre de la tabla en la base de datos como "cliente".

public class Cliente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Indica que este campo es la clave primaria y que su valor será autogenerado (auto-increment) por la base de datos.

    private Long id;
    // Identificador único del cliente.

    private String nombre;
    // Nombre completo del cliente.

    private String email;
    // Correo electrónico del cliente.

    private String telefono;
    // Número telefónico del cliente.

    private String direccion;
    // Dirección física o postal del cliente.

    // Getters y setters para acceder y modificar cada campo.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
}
