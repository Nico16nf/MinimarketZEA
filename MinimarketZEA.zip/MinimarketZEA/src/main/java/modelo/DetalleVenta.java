package modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "detalle_venta")
// Define el nombre de la tabla en la base de datos como "detalle_venta".

public class DetalleVenta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único del detalle de venta.

    @ManyToOne
    @JoinColumn(name = "venta_id")
    // Relación muchos a uno con la entidad Venta, usando la columna "venta_id".

    private Venta venta;
    // Venta a la que pertenece este detalle.

    @ManyToOne
    @JoinColumn(name = "producto_id")
    // Relación muchos a uno con la entidad Producto, usando la columna "producto_id".

    private Producto producto;
    // Producto vendido en este detalle.

    private Integer cantidad;
    // Cantidad de unidades vendidas de este producto.

    private Double precioUnitario;
    // Precio unitario aplicado a cada producto en esta venta.

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }

    public Double getPrecioUnitario() {
        return precioUnitario;
    }

    public void setPrecioUnitario(Double precioUnitario) {
        this.precioUnitario = precioUnitario;
    }
}
