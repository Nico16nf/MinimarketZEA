package modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "usuario")
// Define el nombre de la tabla en la base de datos como "usuario".

public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único del usuario.

    private String nombreUsuario;
    // Nombre de usuario para login o identificación.

    private String email;
    // Correo electrónico del usuario.

    private String contraseña;
    // Contraseña del usuario (se recomienda almacenar la contraseña en forma cifrada).

    private String rol;
    // Rol del usuario en el sistema, por ejemplo: "ADMIN", "CLIENTE".

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreUsuario() {
        return nombreUsuario;
    }

    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = nombreUsuario;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }
}
