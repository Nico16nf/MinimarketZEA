package modelo;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "venta")
// Define el nombre de la tabla en la base de datos como "venta".

public class Venta {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único de la venta.

    @OneToOne
    @JoinColumn(name = "compra_id")
    // Define una relación uno a uno con la entidad Compra, usando la columna "compra_id".

    private Compra compra;
    // Compra asociada a esta venta.

    private LocalDateTime fechaVenta;
    // Fecha y hora en que se realizó la venta.

    private Double total;
    // Total monetario de la venta.

    @OneToMany(mappedBy = "venta", cascade = CascadeType.ALL)
    // Define una relación uno a muchos con la entidad DetalleVenta.
    // El atributo "venta" en DetalleVenta es el dueño de la relación.
    // Cascade.ALL indica que operaciones sobre Venta se propagan a sus detalles.

    private List<DetalleVenta> detalles;
    // Lista de detalles o productos incluidos en esta venta.

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDateTime getFechaVenta() {
        return fechaVenta;
    }

    public void setFechaVenta(LocalDateTime fechaVenta) {
        this.fechaVenta = fechaVenta;
    }

    public Compra getCompra() {
        return compra;
    }

    public void setCompra(Compra compra) {
        this.compra = compra;
    }

    public Double getTotal() {
        return total;
    }

    public void setTotal(Double total) {
        this.total = total;
    }

    public List<DetalleVenta> getDetalles() {
        return detalles;
    }

    public void setDetalles(List<DetalleVenta> detalles) {
        this.detalles = detalles;
    }
}

