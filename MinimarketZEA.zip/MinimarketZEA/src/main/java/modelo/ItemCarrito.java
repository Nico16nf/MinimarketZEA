package modelo;

import jakarta.persistence.*;

@Entity
@Table(name = "item_carrito")
// Define el nombre de la tabla en la base de datos como "item_carrito".

public class ItemCarrito {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como clave primaria autogenerada (auto-increment).

    private Long id;
    // Identificador único del ítem en el carrito.

    @ManyToOne
    @JoinColumn(name = "cliente_id")
    // Relación muchos a uno con la entidad Cliente, usando la columna "cliente_id".

    private Cliente cliente;
    // Cliente al que pertenece este ítem en el carrito.

    @ManyToOne
    @JoinColumn(name = "producto_id")
    // Relación muchos a uno con la entidad Producto, usando la columna "producto_id".

    private Producto producto;
    // Producto agregado al carrito.

    private Integer cantidad;
    // Cantidad de unidades del producto en el carrito.

    // Getters y setters para todos los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }

    public Integer getCantidad() {
        return cantidad;
    }

    public void setCantidad(Integer cantidad) {
        this.cantidad = cantidad;
    }
}
