package modelo;

import jakarta.persistence.*;

@Entity
// Indica que esta clase es una entidad JPA y será mapeada a una tabla en la base de datos.

@Table(name = "boleta_pdf")
// Define el nombre de la tabla en la base de datos como "boleta_pdf".

public class BoletaPdf {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    // Marca este campo como la clave primaria y especifica que su valor será autogenerado por la base de datos (auto-increment).

    private Long id;
    // Identificador único de la boleta PDF.

    @OneToOne
    @JoinColumn(name = "venta_id")
    // Define una relación uno a uno con la entidad Venta, vinculada por la columna "venta_id" en esta tabla.

    private Venta venta;
    // Referencia a la venta asociada a esta boleta.

    @Lob
    // Indica que este campo almacena un objeto grande (Large Object), adecuado para datos binarios como archivos PDF.

    private byte[] archivoPdf;
    // Contenido binario del archivo PDF.

    // Getters y setters para acceder y modificar los campos.

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Venta getVenta() {
        return venta;
    }

    public void setVenta(Venta venta) {
        this.venta = venta;
    }

    public byte[] getArchivoPdf() {
        return archivoPdf;
    }

    public void setArchivoPdf(byte[] archivoPdf) {
        this.archivoPdf = archivoPdf;
    }
}
