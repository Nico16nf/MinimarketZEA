package utilidades;

import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Text;
import java.io.File;
import java.io.IOException;

public class GeneradorPDF {

    // Método para generar un PDF básico con texto simple
    public void generarPDF(String rutaArchivo, String contenido) throws IOException {
        // Crear un escritor para el archivo PDF en la ruta especificada
        PdfWriter writer = new PdfWriter(rutaArchivo);

        // Crear un documento PDF usando el escritor
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        // Cargar una fuente estándar (Helvetica)
        PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);

        // Crear un párrafo y agregarle el texto con la fuente, tamaño y color definidos
        Paragraph paragraph = new Paragraph();
        paragraph.add(new Text(contenido).setFont(font).setFontSize(12).setFontColor(ColorConstants.BLACK));

        // Añadir el párrafo al documento
        document.add(paragraph);

        // Cerrar el documento para guardar y liberar recursos
        document.close();
    }

    // Método para generar un PDF con título y cuerpo de texto separados
    public void generarPDFConTitulo(String rutaArchivo, String titulo, String contenido) throws IOException {
        // Crear un escritor para el archivo PDF en la ruta especificada
        PdfWriter writer = new PdfWriter(rutaArchivo);

        // Crear un documento PDF usando el escritor
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        // Cargar la fuente estándar (Helvetica)
        PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);

        // Crear un párrafo para el título con fuente, tamaño más grande y color azul
        Paragraph tituloParrafo = new Paragraph();
        tituloParrafo.add(new Text(titulo).setFont(font).setFontSize(18).setFontColor(ColorConstants.BLUE));
        document.add(tituloParrafo);

        // Añadir un salto de línea para separar título y contenido
        document.add(new Paragraph("\n"));

        // Crear un párrafo para el contenido con fuente y tamaño normales
        Paragraph contenidoParrafo = new Paragraph();
        contenidoParrafo.add(new Text(contenido).setFont(font).setFontSize(12).setFontColor(ColorConstants.BLACK));
        document.add(contenidoParrafo);

        // Cerrar el documento para guardar y liberar recursos
        document.close();
    }

    // Método main para probar la generación del PDF
    public static void main(String[] args) {
        GeneradorPDF generadorPDF = new GeneradorPDF();
        try {
            // Generar un PDF con título y texto en la ruta "documento.pdf"
            generadorPDF.generarPDFConTitulo("documento.pdf", "Reporte de Ventas", "Este es un documento generado con iText.");
            System.out.println("PDF generado exitosamente.");
        } catch (IOException e) {
            // Manejo de error en caso de fallo al crear el PDF
            System.err.println("Error al generar el PDF: " + e.getMessage());
        }
    }
}
