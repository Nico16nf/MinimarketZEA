package utilidades;

import java.text.SimpleDateFormat;
import java.util.Date;

public class UtilFechas {

    // Obtener la fecha actual en formato yyyy-MM-dd
    public static String obtenerFechaActual() {
        // Crear un formateador para fechas con patrón "yyyy-MM-dd"
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        // Obtener la fecha actual y formatearla como String
        return sdf.format(new Date());
    }

    // Obtener la fecha actual en formato personalizado que se recibe como parámetro
    public static String obtenerFechaActualConFormato(String formato) {
        // Crear un formateador con el patrón recibido
        SimpleDateFormat sdf = new SimpleDateFormat(formato);
        // Obtener la fecha actual y formatearla con el patrón personalizado
        return sdf.format(new Date());
    }

    // Convertir una cadena de texto a un objeto Date según el formato especificado
    public static Date convertirStringADate(String fechaStr, String formato) throws Exception {
        // Crear un formateador con el patrón de fecha esperado
        SimpleDateFormat sdf = new SimpleDateFormat(formato);
        // Intentar parsear la cadena a Date, puede lanzar excepción si no coincide el formato
        return sdf.parse(fechaStr);
    }

    // Comparar dos objetos Date para determinar si son exactamente iguales (fecha y hora)
    public static boolean compararFechas(Date fecha1, Date fecha2) {
        // Usar el método equals para comparar fecha y hora completas
        return fecha1.equals(fecha2);
    }

    // Método principal para probar las funciones anteriores
    public static void main(String[] args) {
        // Mostrar la fecha actual con formato yyyy-MM-dd
        System.out.println("Fecha actual: " + obtenerFechaActual());
        // Mostrar la fecha actual con un formato personalizado, por ejemplo dd/MM/yyyy
        System.out.println("Fecha personalizada: " + obtenerFechaActualConFormato("dd/MM/yyyy"));

        try {
            // Convertir dos cadenas a objetos Date usando formato yyyy-MM-dd
            Date fecha1 = convertirStringADate("2025-05-20", "yyyy-MM-dd");
            Date fecha2 = convertirStringADate("2025-05-20", "yyyy-MM-dd");
            // Comparar si las dos fechas son iguales y mostrar resultado
            System.out.println("Fechas iguales: " + compararFechas(fecha1, fecha2));
        } catch (Exception e) {
            // Capturar y mostrar cualquier error ocurrido durante la conversión de fechas
            System.err.println("Error en la conversión de fechas: " + e.getMessage());
        }
    }
}

