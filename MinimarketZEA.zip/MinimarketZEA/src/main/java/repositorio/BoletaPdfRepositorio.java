package repositorio;

import modelo.BoletaPdf;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
// Marca esta interfaz como un componente Spring para la gestión de datos (DAO).

public interface BoletaPdfRepositorio extends JpaRepository<BoletaPdf, Long> {
    // Extiende JpaRepository para proveer operaciones CRUD y más para la entidad BoletaPdf.

    // Método personalizado para buscar una boleta PDF según el ID de la venta asociada.
    BoletaPdf findByVentaId(Long ventaId);
}

