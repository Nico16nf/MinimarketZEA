package repositorio;

import modelo.DetalleVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
// Marca esta interfaz como componente Spring para la gestión de acceso a datos.

public interface DetalleVentaRepositorio extends JpaRepository<DetalleVenta, Long> {
    // Hereda métodos CRUD para la entidad DetalleVenta.

    // Método para obtener todos los detalles asociados a una venta específica por su ID.
    List<DetalleVenta> findByVentaId(Long ventaId);

    // Método para obtener todos los detalles que contienen un producto específico por su ID.
    List<DetalleVenta> findByProductoId(Long productoId);
}

