package repositorio;

import modelo.Pago;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository

public interface PagoRepositorio extends JpaRepository<Pago, Long> {
    // Hereda métodos CRUD para la entidad Pago.

    // Obtiene todos los pagos asociados a una compra específica por su ID.
    List<Pago> findByCompraId(Long compraId);

    // Obtiene todos los pagos filtrados por su estado (por ejemplo: "PENDIENTE", "CONFIRMADO").
    List<Pago> findByEstadoPago(String estadoPago);

    // Verifica si existe un pago con un número de operación específico.
    boolean existsByNroOperacion(String nroOperacion);
}

