package repositorio;

import modelo.Proveedor;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ProveedorRepositorio extends JpaRepository<Proveedor, Long> {
    // Hereda métodos CRUD para la entidad Proveedor.

    // Busca un proveedor por su nombre exacto, devuelve un Optional para manejar la posible ausencia.
    Optional<Proveedor> findByNombre(String nombre);

    // Verifica si existe un proveedor con un nombre dado.
    boolean existsByNombre(String nombre);
}

