package repositorio;

import modelo.ItemCarrito;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository

public interface ItemCarritoRepositorio extends JpaRepository<ItemCarrito, Long> {
    // Hereda métodos CRUD para la entidad ItemCarrito.

    // Obtiene todos los items del carrito que pertenecen a un cliente específico.
    List<ItemCarrito> findByClienteId(Long clienteId);

    // Verifica si existe un item en el carrito con un cliente y producto específicos.
    boolean existsByClienteIdAndProductoId(Long clienteId, Long productoId);

    // Obtiene el item del carrito para un cliente y producto específicos.
    ItemCarrito findByClienteIdAndProductoId(Long clienteId, Long productoId);
}
