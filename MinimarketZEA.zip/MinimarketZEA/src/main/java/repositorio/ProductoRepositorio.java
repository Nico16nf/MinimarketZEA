package repositorio;

import modelo.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductoRepositorio extends JpaRepository<Producto, Long> {
    // Hereda métodos CRUD para la entidad Producto.

    // Busca productos cuyo nombre contenga el texto dado, ignorando mayúsculas/minúsculas.
    List<Producto> findByNombreContainingIgnoreCase(String nombre);

    // Obtiene productos asociados a un proveedor específico por su ID.
    List<Producto> findByProveedorId(Long proveedorId);

    // Verifica si existe un producto con un nombre exacto dado.
    boolean existsByNombre(String nombre);
}
