package repositorio;

import modelo.Compra;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
// Marca esta interfaz como componente Spring para acceso a datos.

public interface CompraRepositorio extends JpaRepository<Compra, Long> {
    // Hereda métodos CRUD para la entidad Compra.

    // Obtiene todas las compras asociadas a un cliente por su id.
    List<Compra> findByClienteId(Long clienteId);

    // Obtiene todas las compras cuyo estado coincida con el parámetro (ej. "PENDIENTE").
    List<Compra> findByEstado(String estado);

    // Obtiene todas las compras filtradas por método de pago (ej. "YAPE").
    List<Compra> findByMetodoPago(String metodoPago);

    // Obtiene todas las compras entre dos fechas dadas (fechaInicio y fechaFin).
    // **Aquí hay un detalle:** Las fechas deberían ser de tipo `LocalDateTime` o `Date` para comparar correctamente,
    // pero en tu método están declaradas como `String`, lo cual puede generar problemas en la consulta.
    List<Compra> findByFechaBetween(String fechaInicio, String fechaFin);
}
