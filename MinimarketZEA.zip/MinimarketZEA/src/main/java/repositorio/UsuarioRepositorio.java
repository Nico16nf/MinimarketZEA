package repositorio;

import modelo.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UsuarioRepositorio extends JpaRepository<Usuario, Long> {
    // Hereda métodos CRUD para la entidad Usuario.

    // Busca un usuario por su nombre de usuario, devuelve Optional para manejar ausencia.
    Optional<Usuario> findByNombreUsuario(String nombreUsuario);

    // Busca un usuario por su correo electrónico.
    Optional<Usuario> findByEmail(String email);

    // Verifica si existe un usuario con un correo electrónico específico.
    boolean existsByEmail(String email);
}

