package repositorio;

import modelo.Venta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface VentaRepositorio extends JpaRepository<Venta, Long> {
    // Hereda métodos CRUD para la entidad Venta.

    // Obtiene ventas asociadas a compras realizadas por un cliente específico.
    List<Venta> findByCompraClienteId(Long clienteId);

    // Obtiene ventas filtradas según el estado de la compra relacionada.
    List<Venta> findByCompraEstado(String estado);

    // Obtiene ventas realizadas entre dos fechas.
    List<Venta> findByFechaVentaBetween(LocalDateTime fechaInicio, LocalDateTime fechaFin);
}

