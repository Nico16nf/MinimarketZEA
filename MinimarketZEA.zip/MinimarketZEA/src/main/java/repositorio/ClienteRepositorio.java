package repositorio;

import modelo.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
// Marca esta interfaz como un componente Spring para operaciones de acceso a datos.

public interface ClienteRepositorio extends JpaRepository<Cliente, Long> {
    // Extiende JpaRepository para proporcionar operaciones CRUD sobre la entidad Cliente.

    // Método para buscar un cliente por su email. Devuelve Optional para manejar ausencia.
    Optional<Cliente> findByEmail(String email);

    // Método para verificar si existe un cliente con un número de teléfono dado.
    boolean existsByTelefono(String telefono);
}

