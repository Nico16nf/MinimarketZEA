package servicio;

import modelo.Compra;
import modelo.Pago;
import repositorio.PagoRepositorio;
import repositorio.CompraRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
// Marca esta clase como un servicio Spring para manejar lógica relacionada con pagos.

public class ServicioPago {

    private final PagoRepositorio pagoRepositorio;
    private final CompraRepositorio compraRepositorio;
    // Repositorios para acceder a datos de pagos y compras.

    public ServicioPago(PagoRepositorio pagoRepositorio, CompraRepositorio compraRepositorio) {
        this.pagoRepositorio = pagoRepositorio;
        this.compraRepositorio = compraRepositorio;
    }
    // Constructor para inyección de dependencias.

    public Pago crearPago(Pago pago, Long compraId) {
        // Crea un nuevo pago asociado a una compra específica.

        Compra compra = compraRepositorio.findById(compraId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Compra no encontrada con id " + compraId));
        // Busca la compra por ID o lanza excepción si no existe.

        pago.setCompra(compra);
        // Asocia la compra al pago.

        return pagoRepositorio.save(pago);
        // Guarda y retorna el pago creado.
    }

    public Pago obtenerPorId(Long id) {
        // Obtiene un pago por su ID o lanza excepción si no existe.

        return pagoRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Pago no encontrado con id " + id));
    }

    public List<Pago> listarTodos() {
        // Retorna todos los pagos registrados.

        return pagoRepositorio.findAll();
    }

    public Pago actualizarPago(Long id, Pago datosPago) {
        // Actualiza un pago existente con nuevos datos.

        Pago pago = obtenerPorId(id);
        // Busca el pago o lanza excepción.

        pago.setTipoPago(datosPago.getTipoPago());
        pago.setNroOperacion(datosPago.getNroOperacion());
        pago.setDatosCliente(datosPago.getDatosCliente());
        pago.setEstadoPago(datosPago.getEstadoPago());
        // Actualiza los campos del pago.

        return pagoRepositorio.save(pago);
        // Guarda y retorna el pago actualizado.
    }

    public void eliminarPago(Long id) {
        // Elimina un pago por su ID.

        Pago pago = obtenerPorId(id);
        // Busca el pago o lanza excepción.

        pagoRepositorio.delete(pago);
        // Elimina el pago.
    }
}
