package servicio;

import modelo.Proveedor;
import repositorio.ProveedorRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
// Marca esta clase como un servicio Spring para manejar la lógica relacionada con proveedores.

public class ServicioProveedor {

    private final ProveedorRepositorio proveedorRepositorio;
    // Repositorio para acceder y manipular datos de proveedores.

    public ServicioProveedor(ProveedorRepositorio proveedorRepositorio) {
        this.proveedorRepositorio = proveedorRepositorio;
    }
    // Constructor para inyección de dependencias.

    public Proveedor crearProveedor(Proveedor proveedor) {
        // Crea y guarda un nuevo proveedor en la base de datos.
        return proveedorRepositorio.save(proveedor);
    }

    public Proveedor obtenerPorId(Long id) {
        // Busca un proveedor por su ID o lanza excepción si no existe.
        return proveedorRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Proveedor no encontrado con id " + id));
    }

    public List<Proveedor> listarTodos() {
        // Devuelve todos los proveedores registrados.
        return proveedorRepositorio.findAll();
    }

    public Proveedor actualizarProveedor(Long id, Proveedor datosProveedor) {
        // Actualiza un proveedor existente con nuevos datos.

        Proveedor proveedor = obtenerPorId(id);
        // Obtiene el proveedor o lanza excepción si no existe.

        proveedor.setNombre(datosProveedor.getNombre());
        proveedor.setContacto(datosProveedor.getContacto());
        // Actualiza los atributos relevantes.

        return proveedorRepositorio.save(proveedor);
        // Guarda y retorna el proveedor actualizado.
    }

    public void eliminarProveedor(Long id) {
        // Elimina un proveedor por su ID.

        Proveedor proveedor = obtenerPorId(id);
        // Obtiene el proveedor o lanza excepción si no existe.

        proveedorRepositorio.delete(proveedor);
        // Elimina el proveedor.
    }
}
