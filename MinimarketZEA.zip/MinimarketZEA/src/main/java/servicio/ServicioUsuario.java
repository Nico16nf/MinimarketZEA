package servicio;

import modelo.Usuario;
import repositorio.UsuarioRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
// Marca esta clase como un servicio Spring para manejar la lógica de negocio relacionada con usuarios.

public class ServicioUsuario {

    private final UsuarioRepositorio usuarioRepositorio;
    // Repositorio para acceder y manipular datos de usuarios.

    public ServicioUsuario(UsuarioRepositorio usuarioRepositorio) {
        this.usuarioRepositorio = usuarioRepositorio;
    }
    // Constructor para inyección de dependencias.

    public Usuario crearUsuario(Usuario usuario) {
        // Crea y guarda un nuevo usuario en la base de datos.
        return usuarioRepositorio.save(usuario);
    }

    public Usuario obtenerPorId(Long id) {
        // Busca un usuario por su ID o lanza excepción si no existe.
        return usuarioRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Usuario no encontrado con id " + id));
    }

    public List<Usuario> listarTodos() {
        // Devuelve todos los usuarios registrados.
        return usuarioRepositorio.findAll();
    }

    public Usuario actualizarUsuario(Long id, Usuario datosUsuario) {
        // Actualiza un usuario existente con nuevos datos.

        Usuario usuario = obtenerPorId(id);
        // Obtiene el usuario o lanza excepción si no existe.

        usuario.setNombreUsuario(datosUsuario.getNombreUsuario());
        usuario.setEmail(datosUsuario.getEmail());
        usuario.setContraseña(datosUsuario.getContraseña());
        usuario.setRol(datosUsuario.getRol());
        // Actualiza los campos relevantes.

        return usuarioRepositorio.save(usuario);
        // Guarda y retorna el usuario actualizado.
    }

    public void eliminarUsuario(Long id) {
        // Elimina un usuario por su ID.

        Usuario usuario = obtenerPorId(id);
        // Obtiene el usuario o lanza excepción si no existe.

        usuarioRepositorio.delete(usuario);
        // Elimina el usuario.
    }
}


