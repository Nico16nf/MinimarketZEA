package servicio;

import modelo.ItemCarrito;
import modelo.Cliente;
import modelo.Producto;
import repositorio.ItemCarritoRepositorio;
import repositorio.ClienteRepositorio;
import repositorio.ProductoRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
// Marca esta clase como un servicio Spring, manejando lógica de negocio relacionada con el carrito.

public class ServicioCarrito {

    private final ItemCarritoRepositorio itemCarritoRepositorio;
    private final ClienteRepositorio clienteRepositorio;
    private final ProductoRepositorio productoRepositorio;
    // Repositorios necesarios para manejar items del carrito, clientes y productos.

    public ServicioCarrito(ItemCarritoRepositorio itemCarritoRepositorio,
                           ClienteRepositorio clienteRepositorio,
                           ProductoRepositorio productoRepositorio) {
        this.itemCarritoRepositorio = itemCarritoRepositorio;
        this.clienteRepositorio = clienteRepositorio;
        this.productoRepositorio = productoRepositorio;
    }
    // Constructor para inyección de dependencias.

    public ItemCarrito agregarProductoAlCarrito(Long clienteId, Long productoId, Integer cantidad) {
        // Método para agregar un producto al carrito de un cliente.

        Cliente cliente = clienteRepositorio.findById(clienteId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado con id " + clienteId));
        // Busca el cliente por id; lanza excepción si no existe.

        Producto producto = productoRepositorio.findById(productoId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no encontrado con id " + productoId));
        // Busca el producto por id; lanza excepción si no existe.

        ItemCarrito item = new ItemCarrito();
        item.setCliente(cliente);
        item.setProducto(producto);
        item.setCantidad(cantidad);
        // Crea un nuevo item de carrito con el cliente, producto y cantidad.

        return itemCarritoRepositorio.save(item);
        // Guarda el item en la base de datos y retorna el objeto persistido.
    }

    public List<ItemCarrito> obtenerCarritoPorCliente(Long clienteId) {
        // Obtiene todos los items del carrito para un cliente específico.

        return itemCarritoRepositorio.findByClienteId(clienteId);
    }

    public void eliminarProductoDelCarrito(Long clienteId, Long productoId) {
        // Elimina un producto específico del carrito de un cliente.

        ItemCarrito item = itemCarritoRepositorio.findByClienteIdAndProductoId(clienteId, productoId);
        // Busca el item por cliente y producto.

        if (item != null) {
            itemCarritoRepositorio.delete(item);
            // Si existe, lo elimina.
        }
    }
}

