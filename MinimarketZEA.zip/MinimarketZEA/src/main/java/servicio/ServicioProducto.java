package servicio;

import modelo.Producto;
import repositorio.ProductoRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
// Marca esta clase como un servicio Spring para manejar la lógica relacionada con productos.

public class ServicioProducto {

    private final ProductoRepositorio productoRepositorio;
    // Repositorio para acceder y manipular datos de productos.

    public ServicioProducto(ProductoRepositorio productoRepositorio) {
        this.productoRepositorio = productoRepositorio;
    }
    // Constructor para inyección de dependencias.

    public Producto crearProducto(Producto producto) {
        // Crea y guarda un nuevo producto en la base de datos.
        return productoRepositorio.save(producto);
    }

    public Producto obtenerPorId(Long id) {
        // Busca un producto por su ID o lanza excepción si no existe.
        return productoRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Producto no encontrado con id " + id));
    }

    public List<Producto> listarTodos() {
        // Devuelve todos los productos registrados.
        return productoRepositorio.findAll();
    }

    public Producto actualizarProducto(Long id, Producto datosProducto) {
        // Actualiza un producto existente con nuevos datos.

        Producto producto = obtenerPorId(id);
        // Obtiene el producto o lanza excepción si no existe.

        producto.setNombre(datosProducto.getNombre());
        producto.setDescripcion(datosProducto.getDescripcion());
        producto.setPrecio(datosProducto.getPrecio());
        producto.setStock(datosProducto.getStock());
        // Actualiza los atributos relevantes.

        return productoRepositorio.save(producto);
        // Guarda y retorna el producto actualizado.
    }

    public void eliminarProducto(Long id) {
        // Elimina un producto por su ID.

        Producto producto = obtenerPorId(id);
        // Obtiene el producto o lanza excepción si no existe.

        productoRepositorio.delete(producto);
        // Elimina el producto.
    }
}

