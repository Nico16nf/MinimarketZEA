package servicio;

import modelo.BoletaPdf;
import modelo.Venta;
import repositorio.BoletaPdfRepositorio;
import repositorio.VentaRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioBoletaPdf {

    private final BoletaPdfRepositorio boletaPdfRepositorio;
    private final VentaRepositorio ventaRepositorio;
    // Repositorios necesarios para acceder a datos de boletas y ventas.

    public ServicioBoletaPdf(BoletaPdfRepositorio boletaPdfRepositorio, VentaRepositorio ventaRepositorio) {
        this.boletaPdfRepositorio = boletaPdfRepositorio;
        this.ventaRepositorio = ventaRepositorio;
    }
    // Constructor para inyectar los repositorios mediante inyección de dependencias.

    public BoletaPdf crearBoleta(BoletaPdf boleta, Long ventaId) {
        // Método para crear una nueva boleta PDF asociada a una venta.

        Venta venta = ventaRepositorio.findById(ventaId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Venta no encontrada con id " + ventaId));
        // Busca la venta por ID; si no existe, lanza excepción personalizada.

        boleta.setVenta(venta);
        // Asocia la venta encontrada a la boleta.

        return boletaPdfRepositorio.save(boleta);
        // Guarda la boleta en la base de datos y la retorna.
    }

    public BoletaPdf obtenerPorId(Long id) {
        // Busca una boleta por su ID.

        return boletaPdfRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Boleta no encontrada con id " + id));
        // Retorna la boleta o lanza excepción si no existe.
    }

    public List<BoletaPdf> listarTodas() {
        // Retorna todas las boletas almacenadas.

        return boletaPdfRepositorio.findAll();
    }

    public BoletaPdf actualizarBoleta(Long id, BoletaPdf datosBoleta) {
        // Actualiza el archivo PDF de una boleta existente.

        BoletaPdf boleta = obtenerPorId(id);
        // Busca la boleta; si no existe, lanza excepción.

        boleta.setArchivoPdf(datosBoleta.getArchivoPdf());
        // Actualiza el contenido binario del PDF.

        return boletaPdfRepositorio.save(boleta);
        // Guarda los cambios y retorna la boleta actualizada.
    }

    public void eliminarBoleta(Long id) {
        // Elimina una boleta por su ID.

        BoletaPdf boleta = obtenerPorId(id);
        // Busca la boleta; si no existe, lanza excepción.

        boletaPdfRepositorio.delete(boleta);
        // Elimina la boleta de la base de datos.
    }
}
