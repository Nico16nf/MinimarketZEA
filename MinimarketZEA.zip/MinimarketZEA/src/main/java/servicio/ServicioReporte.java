package servicio;

import modelo.Compra;
import repositorio.CompraRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioReporte {

    private final CompraRepositorio compraRepositorio;
    // Repositorio para acceder a los datos de compra.

    public ServicioReporte(CompraRepositorio compraRepositorio) {
        this.compraRepositorio = compraRepositorio;
    }
    // Constructor para inyectar la dependencia.

    // Generar reporte de compras por cliente
    public List<Compra> generarReporteComprasPorCliente(Long clienteId) {
        return compraRepositorio.findByClienteId(clienteId);
    }
    // Obtiene la lista de compras realizadas por un cliente específico.

    // Generar reporte de compras por estado
    public List<Compra> generarReporteComprasPorEstado(String estado) {
        return compraRepositorio.findByEstado(estado);
    }
    // Obtiene la lista de compras filtradas por su estado (ej. PENDIENTE, PAGADO).

    // Generar reporte de compras por método de pago
    public List<Compra> generarReporteComprasPorMetodoPago(String metodoPago) {
        return compraRepositorio.findByMetodoPago(metodoPago);
    }
    // Obtiene la lista de compras filtradas por el método de pago (ej. YAPE, TRANSFERENCIA).

    // Reporte de compras entre fechas
    public List<Compra> generarReportePorFecha(String fechaInicio, String fechaFin) {
        return compraRepositorio.findByFechaBetween(fechaInicio, fechaFin);
    }
    // Obtiene la lista de compras realizadas entre dos fechas.
    // Nota: Es preferible que los parámetros fechaInicio y fechaFin sean de tipo LocalDateTime para un manejo correcto.
}


