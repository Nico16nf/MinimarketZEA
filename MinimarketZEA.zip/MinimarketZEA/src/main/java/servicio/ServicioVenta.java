package servicio;

import modelo.Compra;
import modelo.Venta;
import repositorio.VentaRepositorio;
import repositorio.CompraRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioVenta {

    private final VentaRepositorio ventaRepositorio;
    private final CompraRepositorio compraRepositorio;
    // Repositorios necesarios para manejar ventas y compras.

    public ServicioVenta(VentaRepositorio ventaRepositorio, CompraRepositorio compraRepositorio) {
        this.ventaRepositorio = ventaRepositorio;
        this.compraRepositorio = compraRepositorio;
    }
    // Constructor para inyección de dependencias.

    public Venta crearVenta(Venta venta, Long compraId) {
        // Crea una venta nueva asociada a una compra existente.

        Compra compra = compraRepositorio.findById(compraId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Compra no encontrada con id " + compraId));
        // Busca la compra por id; si no existe, lanza excepción.

        venta.setCompra(compra);
        // Asocia la compra a la venta.

        return ventaRepositorio.save(venta);
        // Guarda y retorna la venta creada.
    }

    public Venta obtenerPorId(Long id) {
        // Busca una venta por su ID o lanza excepción si no existe.

        return ventaRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Venta no encontrada con id " + id));
    }

    public List<Venta> listarTodas() {
        // Retorna todas las ventas registradas.

        return ventaRepositorio.findAll();
    }

    public Venta actualizarVenta(Long id, Venta datosVenta) {
        // Actualiza una venta existente con nuevos datos.

        Venta venta = obtenerPorId(id);
        // Busca la venta o lanza excepción si no existe.

        venta.setFechaVenta(datosVenta.getFechaVenta());
        venta.setTotal(datosVenta.getTotal());
        // Actualiza los campos relevantes.

        return ventaRepositorio.save(venta);
        // Guarda y retorna la venta actualizada.
    }

    public void eliminarVenta(Long id) {
        // Elimina una venta por su ID.

        Venta venta = obtenerPorId(id);
        // Busca la venta o lanza excepción si no existe.

        ventaRepositorio.delete(venta);
        // Elimina la venta.
    }
}


