package servicio;

import modelo.Cliente;
import modelo.Compra;
import repositorio.CompraRepositorio;
import repositorio.ClienteRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
// Marca esta clase como un servicio Spring para lógica de negocio relacionada con compras.

public class ServicioCompra {

    private final CompraRepositorio compraRepositorio;
    private final ClienteRepositorio clienteRepositorio;
    // Repositorios necesarios para manejar compras y clientes.

    public ServicioCompra(CompraRepositorio compraRepositorio, ClienteRepositorio clienteRepositorio) {
        this.compraRepositorio = compraRepositorio;
        this.clienteRepositorio = clienteRepositorio;
    }
    // Constructor para inyección de dependencias.

    public Compra crearCompra(Compra compra, Long clienteId) {
        // Crea una compra nueva asociada a un cliente.

        Cliente cliente = clienteRepositorio.findById(clienteId)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado con id " + clienteId));
        // Busca el cliente por id; si no existe, lanza excepción.

        compra.setCliente(cliente);
        // Asocia el cliente a la compra.

        return compraRepositorio.save(compra);
        // Guarda la compra y la retorna.
    }

    public Compra obtenerPorId(Long id) {
        // Obtiene una compra por su ID o lanza excepción si no existe.

        return compraRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Compra no encontrada con id " + id));
    }

    public List<Compra> listarTodas() {
        // Devuelve todas las compras registradas.

        return compraRepositorio.findAll();
    }

    public Compra actualizarCompra(Long id, Compra datosCompra) {
        // Actualiza una compra existente con nuevos datos.

        Compra compra = obtenerPorId(id);
        // Obtiene la compra o lanza excepción.

        compra.setTotal(datosCompra.getTotal());
        compra.setEstado(datosCompra.getEstado());
        compra.setMetodoPago(datosCompra.getMetodoPago());
        // Actualiza los campos relevantes.

        return compraRepositorio.save(compra);
        // Guarda y retorna la compra actualizada.
    }

    public void eliminarCompra(Long id) {
        // Elimina una compra por su ID.

        Compra compra = obtenerPorId(id);
        // Obtiene la compra o lanza excepción.

        compraRepositorio.delete(compra);
        // Elimina la compra.
    }
}

