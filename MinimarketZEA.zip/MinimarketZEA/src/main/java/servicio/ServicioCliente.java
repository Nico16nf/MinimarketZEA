package servicio;

import modelo.Cliente;
import repositorio.ClienteRepositorio;
import excepcion.RecursoNoEncontradoException;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ServicioCliente {

    private final ClienteRepositorio clienteRepositorio;
    // Repositorio para acceder y manipular datos de clientes.

    public ServicioCliente(ClienteRepositorio clienteRepositorio) {
        this.clienteRepositorio = clienteRepositorio;
    }
    // Constructor para inyectar la dependencia del repositorio.

    public Cliente crearCliente(Cliente cliente) {
        // Crea y guarda un nuevo cliente en la base de datos.
        return clienteRepositorio.save(cliente);
    }

    public Cliente obtenerPorId(Long id) {
        // Busca un cliente por su ID.
        // Si no existe, lanza excepción personalizada.
        return clienteRepositorio.findById(id)
                .orElseThrow(() -> new RecursoNoEncontradoException("Cliente no encontrado con id " + id));
    }

    public List<Cliente> listarTodos() {
        // Devuelve todos los clientes registrados.
        return clienteRepositorio.findAll();
    }

    public Cliente actualizarCliente(Long id, Cliente datosCliente) {
        // Actualiza los datos de un cliente existente.

        Cliente cliente = obtenerPorId(id);
        // Obtiene el cliente o lanza excepción si no existe.

        cliente.setNombre(datosCliente.getNombre());
        cliente.setEmail(datosCliente.getEmail());
        cliente.setTelefono(datosCliente.getTelefono());
        cliente.setDireccion(datosCliente.getDireccion());
        // Actualiza los campos relevantes.

        return clienteRepositorio.save(cliente);
        // Guarda y retorna el cliente actualizado.
    }

    public void eliminarCliente(Long id) {
        // Elimina un cliente por su ID.

        Cliente cliente = obtenerPorId(id);
        // Obtiene el cliente o lanza excepción si no existe.

        clienteRepositorio.delete(cliente);
        // Elimina el cliente.
    }
}

